public interface Car {
    String gas();
    String brakes();
}
