package p03;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String rank = reader.readLine().toUpperCase();
        String power = reader.readLine().toUpperCase();
        String rank1 = reader.readLine().toUpperCase();
        String power1 = reader.readLine().toUpperCase();
        Card card = new Card(RankPowers.valueOf(rank),SuitPowers.valueOf(power));
        Card card1 = new Card(RankPowers.valueOf(rank1),SuitPowers.valueOf(power1));
       if (card.compareTo(card1) > 0){
           System.out.println(card.toString());
       }
       else{
           System.out.println(card1.toString());
       }
    }
}
